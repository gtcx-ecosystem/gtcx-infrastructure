import boto3
import os
import datetime

def handler(event, context):
    rds = boto3.client('rds')
    db_identifier = os.environ['DB_IDENTIFIER']
    bucket_name = os.environ['BACKUP_BUCKET']
    kms_key_arn = os.environ['KMS_KEY_ARN']

    # Get the latest automated snapshot
    response = rds.describe_db_snapshots(
        DBInstanceIdentifier=db_identifier,
        SnapshotType='automated',
        MaxRecords=20,
    )

    snapshots = sorted(
        response.get('DBSnapshots', []),
        key=lambda s: s.get('SnapshotCreateTime', datetime.datetime.min.replace(tzinfo=datetime.timezone.utc)),
        reverse=True,
    )

    if not snapshots:
        print(f"No automated snapshots found for {db_identifier}")
        return {'status': 'no_snapshots'}

    snapshot = snapshots[0]
    snapshot_arn = snapshot['DBSnapshotArn']
    snapshot_id = snapshot['DBSnapshotIdentifier']
    timestamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%d-%H%M%S')
    export_id = f"gtcx-audit-export-{timestamp}"

    print(f"Starting export of snapshot {snapshot_id} to s3://{bucket_name}/{export_id}")

    rds.start_export_task(
        ExportTaskIdentifier=export_id,
        SourceArn=snapshot_arn,
        S3BucketName=bucket_name,
        IamRoleArn=os.environ.get('EXPORT_ROLE_ARN', ''),
        KmsKeyId=kms_key_arn,
        S3Prefix=export_id,
    )

    return {
        'status': 'export_started',
        'export_id': export_id,
        'snapshot_id': snapshot_id,
    }
